# Tranxit Request Features

* Promocode
* Wallet
* Scheduling Ride
* ETA / Price Estimation
* Stripe Card Payment
* Surge Pricing
* Fleet Management
* User Management
* Provider Management
* Dispatcher Management
* Account Management
* Fleet Management
* Mobile OTP Verification
* Summary / Daily target
* Provider can cancel till the user is picked up.